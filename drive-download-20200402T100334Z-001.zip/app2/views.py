from django.shortcuts import render,redirect
from app2.forms import *
from app2.models import *

# def religion(request):
#     if request.method == "POST":
#       form1= ReligionForm(request.POST)
#       if form1.is_valid():
#           try:
#               form1.save()
#               return redirect("/religion")
#           except:
#               pass
#     else:
#         form1= ReligionForm()
#         religion1 = Religion.objects.all()
#         return render(request,"religion/register.html", {"form1":form1, "religion1": religion1})



# def show_religion(request):
#     religion1 = Religion.objects.all()

#     return render(request, "religion/index.html", {"religion1": religion1} )
# def edit(request,id):
#     religion2 = Religion.objects.get(RELIGION_NO=id)
#     return render(request, "religion/edit.html", { 'religion2':religion2})
# def modify_religion(request,id):
#     religion2 =Religion.objects.get(RELIGION_NO=id)
#     form1 = ReligionForm(request.POST, instance = religion2)
#     # religion2.RELIGION_NO = form1.RELIGION_NO
#     # religion2.RELIGION_NAME = form1.RELIGION_NAME
#     # form1.RELIGION_NO = religion2.A.value#religion2.RELIGION_NO
#     # form1.RELIGION_NAME = religion2.B.value#religion2.RELIGION_NAME
#     if form1.is_valid():
#         form1.save()
#         return redirect("/religion")
#     return render(request, "religion/edit.html", { 'form1':religion2})
# def delete_religion(request,id):
#     religion3 =Religion.objects.get(id=id)
#     religion3.delete()
#     return redirect("/show_religion")
# Create your views here.

# class ClassName(object):
#     # """docstring for ."""
#     model=

from django.views.generic.edit import UpdateView,CreateView
from django.views.generic.list import ListView
from django.shortcuts import render,redirect
from app2.forms import *
from app2.models import *

#start for religion model
def religion(request):
    if request.method == "POST":
      form1= ReligionForm(request.POST)
      if form1.is_valid():
          try:
              form1.save()
              return redirect("/religion")
          except:
              pass
    else:
        form1= ReligionForm()
        religion1 = Religion.objects.all()
        return render(request,"religion/register.html", {"form1":form1, "religion1": religion1})



def show_religion(request):
    religion1 = Religion.objects.all()

    return render(request, "religion/index.html", {"religion1": religion1} )

class ReligionUpdateView(UpdateView):
    # specify the model you want to use
    model = Religion

    # specify the fields
    fields = [
        "RELIGION_NO",
        "RELIGION_NAME"
    ]

    success_url ="religion"

def delete_religion(request,id):
    religion3 =Religion.objects.get(id=id)
    religion3.delete()
    return redirect("/religion")

#End for religion model

#caste

class CasteCreateView(CreateView):
    # specify the model you want to use
    model = Caste
    # specify the fields
    fields = "__all__"
    # can specify success url
    # url to redirect after sucessfully
    # updating details
    success_url ="show_caste"

class CasteUpdateView(UpdateView):
    # specify the model you want to use
    model = Caste

    # specify the fields
    fields = [
        "CASTE_NO",
        "CASTE_NAME"
    ]

    success_url ="caste"

def delete_caste(request,id):
    caste3 =Caste.objects.get(id=id)
    caste3.delete()
    return redirect("/caste")
#End of caste

def suplhead(request):
    if request.method == "POST":
      form1= SuplHeadForm(request.POST)
      if form1.is_valid():
          try:
              form1.save()
              return redirect("/suplhead")
          except:
              pass
    else:
        form1=SuplHeadForm()
        suplhead1 = SuplHead.objects.all()
        return render(request,"caste/register.html", {"form1":form1, "caste1": suplhead1})

class SuplHeadUpdateView(UpdateView):
    # specify the model you want to use
    model = SuplHead

    # specify the fields
    fields = [
        "SUPLNO",
        " SUPLHEAD_NAME"
    ]

    success_url ="suplhead"

def delete_suplhead(request,id):
    suplhead3 =SuplHead.objects.get(id=id)
    suplhead3.delete()
    return redirect("/suplhead")




# title

#start for title model
def title(request):
    if request.method == "POST":
      form1= TitleForm(request.POST)
      if form1.is_valid():
          try:
              form1.save()
              return redirect("/title")
          except:
              pass
    else:
        form1= TitleForm()
        title1 = Title.objects.all()
        return render(request,"title/register.html", {"form1":form1, "title1": title1})


#show title
def show_title(request):
    title1 = Title.objects.all()

    return render(request, "title/index.html", {"title1": title1} )

#update title
class TitleUpdateView(UpdateView):
    # specify the model you want to use
    model = Title

    # specify the fields
    fields = [
        "TITLE_NO",
        "TITLE_NAME"
    ]

    success_url ="title"

#delete title
def delete_title(request,id):
    title3 =Title.objects.get(id=id)
    title3.delete()
    return redirect("/title")


#category

#start for title model
def category(request):
    if request.method == "POST":
      form1= CategoryForm(request.POST)
      if form1.is_valid():
          try:
              form1.save()
              return redirect("/category")
          except:
              pass
    else:
        form1= CategoryForm()
        category1 = Category.objects.all()
        return render(request,"category/register.html", {"form1":form1, "category1": category1})


#show category
def show_category(request):
    category1 = Category.objects.all()

    return render(request, "category/index.html", {"category1": category1} )

#update category
class CategoryUpdateView(UpdateView):
    # specify the model you want to use
    model = Title

    # specify the fields
    fields = [
        "CATEGORY_NO",
        "CATEGORY_NAME"
    ]

    success_url ="category"

#delete category
def delete_category(request,id):
    category3 =Category.objects.get(id=id)
    category3.delete()
    return redirect("/category")

class MainDept_create(CreateView):

    # specify the model for create view
    model = MainDept

    # specify the fields to be displayed

    fields = ['DEPT_NO', 'DEPT_NAME', 'SDEPT']

    success_url ="MainDeptShowView"

class MainDeptShowView(ListView):
    # specify the model you want to use
    model = MainDept

    # specify the fields
    # fields = ['DEPT_NO', 'DEPT_NAME', 'SDEPT']

    # success_url ="MainDept"

class MainDesignation_create(CreateView):

    # specify the model for create view
    model = MainDesignation

    # specify the fields to be displayed

    fields = "__all__"

    success_url ="MainDesignationShowView"

class MainDesignationShowView(ListView):
    # specify the model you want to use
    model = MainDesignation

    # specify the fields
    # fields = ['DEPT_NO', 'DEPT_NAME', 'SDEPT']

    # success_url ="MainDept"

class Staff_create(CreateView):

    # specify the model for create view
    model = Staff

    # specify the fields to be displayed

    fields = "__all__"

    success_url ="StaffShowView"

class StaffShowView(ListView):
    # specify the model you want to use
    model = Staff

    # specify the fields
    # fields = ['DEPT_NO', 'DEPT_NAME', 'SDEPT']

    # success_url ="MainDept"

class Scale_create(CreateView):

    # specify the model for create view
    model = Scale

    # specify the fields to be displayed

    fields = "__all__"

    success_url ="ScaleShowView"

class ScaleShowView(ListView):
    # specify the model you want to use
    model = Scale

    # specify the fields
    # fields = ['DEPT_NO', 'DEPT_NAME', 'SDEPT']

    # success_url ="MainDept"

class TypeTranCreateView(CreateView):
    # specify the model you want to use
    model = TypeTran
    # specify the fields
    fields ="__all__"

    # can specify success url
    # url to redirect after sucessfully
    # updating details
    success_url ="show_typetran"

class TypeTranListView(ListView):

    # specify the model for list view
    model = TypeTran

class AppointmentCreateView(CreateView):
    # specify the model you want to use
    model = Appointment
    # specify the fields
    fields = "__all__"
    # can specify success url
    # url to redirect after sucessfully
    # updating details
    success_url ="show_appointment"

class AppointmentListView(ListView):

    # specify the model for list view
    model = Appointment

class UnderCollegeCreateView(CreateView):
    # specify the model you want to use
    model = UnderCollege
    # specify the fields
    fields = "__all__"
    # can specify success url
    # url to redirect after sucessfully
    # updating details
    success_url ="show_undercollege"

class UnderCollegeListView(ListView):

    # specify the model for list view
    model = UnderCollege








#crud operations : vaibhav
#do not edit

def createtemp(request):
    if request.method == 'POST':
        form = EmployeeInformationForm(request.POST)
        #form.fields["ID_NUMBER"].initial ='24231'
        print(request.POST)
        if form.is_valid():
            form.instance.ID_NUMBER='11111'
            form.save()
            return HttpResponse("data saved")

        else:
            title=Title.objects.all()
            designation_nature=Designation_Nature.objects.all()
            under=Under.objects.all()
            designation=Designation.objects.all()
            department=Department.objects.all()
            staff_type=Staff_Type.objects.all()
            appointment=Appointment.objects.all()
            vacational=Vacational.objects.all()
            bank_name=Bank_Name.objects.all()
            level=Level.objects.all()
            rule=Rule.objects.all()
            gender=Gender.objects.all()
            return render(request,'info/temp.html',{'title':title ,'designation_nature':designation_nature ,'under':under , 'designation':designation ,
            'department':department , 'staff_type':staff_type ,'appointment':appointment ,'vacational':vacational ,'bank_name':bank_name ,
            'level':level ,'rule':rule ,'gender':gender ,'messages':form.errors})

    else:
        title=Title.objects.all()
        designation_nature=Designation_Nature.objects.all()
        under=Under.objects.all()
        designation=Designation.objects.all()
        department=Department.objects.all()
        staff_type=Staff_Type.objects.all()
        appointment=Appointment.objects.all()
        vacational=Vacational.objects.all()
        bank_name=Bank_Name.objects.all()
        level=Level.objects.all()
        rule=Rule.objects.all()
        gender=Gender.objects.all()
        messages=''
        return render(request,'info/temp.html',{'title':title ,'designation_nature':designation_nature ,'under':under , 'designation':designation ,
        'department':department , 'staff_type':staff_type ,'appointment':appointment ,'vacational':vacational ,'bank_name':bank_name ,
        'level':level ,'rule':rule ,'gender':gender,'messages':messages })



def readtemp(request):
    if request.method=='POST':
        id=request.POST['ID_NUMBER']
        try:
            obj= EmployeeInformation.objects.get(ID_NUMBER=id)
            if obj.SEQUENCE_NUMBER!=request.POST['SEQUENCE_NUMBER']:
                 raise Http404("object not found")
                
        except EmployeeInformation.DoesNotExist:
            raise Http404("Object does not exist")
        
        return render(request, 'info/tempread.html', { 'obj': obj })


    else:
        return render(request,'info/tempaskread.html')



def askUpdationtemp(request):
    if request.method=='POST':
        id=request.POST['ID_NUMBER']
        try:
            obj= EmployeeInformation.objects.get(ID_NUMBER=id)
            if obj.SEQUENCE_NUMBER!=request.POST['SEQUENCE_NUMBER']:
                 raise Http404("object not found")
                
        except EmployeeInformation.DoesNotExist:
            raise Http404("Object does not exist")
        

        print(obj.DATE_OF_BIRTH)
        title=Title.objects.all()
        designation_nature=Designation_Nature.objects.all()
        under=Under.objects.all()
        designation=Designation.objects.all()
        department=Department.objects.all()
        staff_type=Staff_Type.objects.all()
        appointment=Appointment.objects.all()
        vacational=Vacational.objects.all()
        bank_name=Bank_Name.objects.all()
        level=Level.objects.all()
        rule=Rule.objects.all()
        gender=Gender.objects.all()
        return render(request, 'info/tempupdate.html', { 'obj': obj ,'title':title ,'designation_nature':designation_nature ,'under':under , 'designation':designation ,
        'department':department , 'staff_type':staff_type ,'appointment':appointment ,'vacational':vacational ,'bank_name':bank_name ,
        'level':level ,'rule':rule ,'gender':gender})

    else:
        return render(request,'info/tempaskupdate.html')



def updatetemp(request):
    if request.method == 'POST':
        id=request.POST['ID_NUMBER']
        try:
            print(id)
            obj= EmployeeInformation.objects.filter(ID_NUMBER=id).get()
            if obj.SEQUENCE_NUMBER!=request.POST['SEQUENCE_NUMBER']:
                 return HttpResponse("object not found")

            
            form = EmployeeInformationForm(request.POST)

            EmployeeInformation.objects.filter(ID_NUMBER=id).delete()
            if form.is_valid():
                """
                var1=request.POST['FIRST_NAME']
                var2=request.POST['MIDDLE_NAME']
                var3=request.POST['LAST_NAME']
                var4=request.POST['FATHER_NAME']
                var5=request.POST['GENDER']
                var6=request.POST['TA']
                var7=request.POST['PT']
                var8=request.POST['QUARTER']
                var9=request.POST['RENT_FREE']
                var10=request.POST['QUARTER_ADDRESS']
                var11=request.POST['HANDICAP']
                var12=request.POST['SENIOR_CITIZEN']
                var13=request.POST['BANK_ACCOUNT_NUMBER']
                var14=request.POST['PF_NUMBER']
                var15=request.POST['PRAN_NUMBER']
                var16=request.POST['INCREMENT_DATE']
                var17=request.POST['DATE_OF_BIRTH']
                var18=request.POST['DATE_OF_JOINING']
                var19=request.POST['DATE_OF_RETIREMENT']
                var20=request.POST['DESIGNATION_NAME']
                var21=request.POST['DESIGNATION']
                var22=request.POST['DEPARTMENT']
                var23=request.POST['STAFF_TYPE']
                var24=request.POST['VACATIONAL']
                var25=request.POST['BANK_NAME']
                var26=request.POST['PAN_NUMBER']
                var27=request.POST['TITLE']
                var28=request.POST['UNDER']
                var29=request.POST['APPOINTMENT']
                var30=request.POST['LEVEL']
                var31=request.POST['BASIC']
                var32=request.POST['PAY_STATUS']
                var33=request.POST['RULE']
                var34=request.POST['REMARK']


                EmployeeInformation.objects.filter(ID_NUMBER=request.POST['ID_NUMBER']).update(FIRST_NAME=var1 , MIDDLE_NAME=var2 , LAST_NAME=var3 , FATHER_NAME=var4 , GENDER=var5 , TA=var6 , 
                PT=var7 , QUARTER=var8 , RENT_FREE=var9, QUARTER_ADDRESS=var10, HANDICAP=var11, SENIOR_CITIZEN=var12, BANK_ACCOUNT_NUMBER=var13,
                PF_NUMBER=var14,PRAN_NUMBER=var15,INCREMENT_DATE=var16,DATE_OF_BIRTH=var17,DATE_OF_JOINING=var18, DATE_OF_RETIREMENT=var19,
                DESIGNATION_NAME=var20,DESIGNATION=var21, DEPARTMENT=var22, STAFF_TYPE=var23 , VACATIONAL=var24 , BANK_NAME=var25 ,
                PAN_NUMBER=var26 , TITLE=var27 , UNDER=var28 , APPOINTMENT=var29 , LEVEL=var30 , BASIC=var31 , PAY_STATUS=var32 ,
                RULE=var33 , REMARK=var34 )
                """
                form.save()
                return HttpResponse("data saved")

            else:
                obj.save()
                return HttpResponse("not updated")
                
        except EmployeeInformation.DoesNotExist:
            return HttpResponse("Object does not exist")

        
        

