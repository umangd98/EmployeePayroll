from django.apps import AppConfig


class App2Config(AppConfig):
    name = 'app2'
